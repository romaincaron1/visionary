package com.romaincaron.analyze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalyzeApplicationTests {

	@Test
	void contextLoads() {
	}

}
