package com.romaincaron.analyze.enums;

public enum EventType {
    MEDIA_SYNCED,
    BATCH_COMPLETED,
    SYNC_COMPLETED,
}