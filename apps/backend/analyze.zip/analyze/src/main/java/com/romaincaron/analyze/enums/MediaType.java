package com.romaincaron.analyze.enums;

public enum MediaType {
    MANGA,
    ANIME,
    MOVIE,
    SERIES
}
