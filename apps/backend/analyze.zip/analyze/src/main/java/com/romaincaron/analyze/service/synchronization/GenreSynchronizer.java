package com.romaincaron.analyze.service.synchronization;

import com.romaincaron.analyze.dto.MediaDto;
import com.romaincaron.analyze.entity.MediaNode;

public interface GenreSynchronizer extends EntitySynchronizer<MediaNode, MediaDto> {
}
