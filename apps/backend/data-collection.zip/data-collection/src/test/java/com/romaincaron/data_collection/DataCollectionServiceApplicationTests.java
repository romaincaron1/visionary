package com.romaincaron.data_collection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCollectionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
