package com.romaincaron.data_collection.enums;

public enum EventType {
    MEDIA_SYNCED,
    BATCH_COMPLETED,
    SYNC_COMPLETED,
}
