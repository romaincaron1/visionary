package com.romaincaron.data_collection.enums;

public enum ConfidenceLevel {
    LOW,
    MEDIUM,
    HIGH
}
