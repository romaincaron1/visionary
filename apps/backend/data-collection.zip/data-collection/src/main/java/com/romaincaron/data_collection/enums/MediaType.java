package com.romaincaron.data_collection.enums;

public enum MediaType {
    MANGA,
    ANIME,
    MOVIE,
    SERIES
}
